/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package army2.server;

import java.util.ArrayList;

/**
 *
 * @author ASD
 */
public class NapTienData {

    public static class NapTienEntry {

        String id;
        String info;
        String url;
        String mssContent;
        String mssTo;
    }

    public static ArrayList<NapTienEntry> entrys;

}
