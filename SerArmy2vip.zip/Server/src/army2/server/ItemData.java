package army2.server;

import java.util.ArrayList;

/**
 *
 * @author ASD
 */
public class ItemData {

    public static final class ItemEntry {

        public String name;
        int buyXu;
        int buyLuong;
    }

    public static ArrayList<ItemEntry> entrys;
    public static byte nItemDcMang[] = {2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1};

}
