<div class="download">
      <div class="bg-content" style="text-align:center;background:#1c3f39;">
        <div id="columns" style="text-align:center">
          <figure>
            <a rel="nofollow" href="/file/LongTinh.jar" title="MobiArmy II">
            <img height="35" src="/public/images/java.png" alt="MobiArmy II">
            <br>
            </a>
            <figcaption><span style="color:rgb(220, 168, 0);">JAR</span> - Màn hình dọc
              <br>
              <br>
            </figcaption>
          </figure>
          <figure>
            <a rel="nofollow" href="/download/java-mh-ngang" title="MobiArmy II">
            <img height="35" src="/public/images/java.png" alt="MobiArmy II">
            </a>
            <figcaption>
              <span style="color:rgb(220, 168, 0);">JAR</span> - Màn hình ngang
              <br>
              <br>
            </figcaption>
          </figure>
          <figure>
            <a rel="nofollow" href="/download/android" title="MobiArmy II">
            <img height="35" src="/public/images/android.png" alt="MobiArmy II">
            </a>
            <figcaption><span style="color:rgb(220, 168, 0);">APK</span> - Android
              <br>
              <br>
            </figcaption>
          </figure>
          <figure>
            <a rel="nofollow" href="/download/pc" title="MobiArmy II">
            <img height="35" src="/public/images/PC.png" alt="MobiArmy II">
            </a>
            <figcaption><span style="color:rgb(220, 168, 0);">Windows</span> - Emulator
              <br>
              <br>
            </figcaption>
          </figure>
        </div>
        <p>
          <a href="/register" title="Đăng kí tài khoản MobiArmy II">
          <img src="/public/images/new.gif" alt="MobiArmy II">
          ĐĂNG KÍ TÀI KHOẢN
          <img src="/public/images/new.gif" alt="MobiArmy II">
          </a>
        </p>
      </div>
    </div>